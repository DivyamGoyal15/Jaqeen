# file: utils/data_manager.py

"""
Data Manager - Safe JSON File Operations
This prevents data corruption by writing to a temp file first, then renaming.
"""

import json
import os
from pathlib import Path
from typing import Any
import tempfile
import shutil

class DataManager:
    """Handles reading and writing JSON files safely."""
    
    def __init__(self, base_dir: str = "data"):
        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(exist_ok=True)
    
    def read_json(self, filename: str, default: Any = None) -> Any:
        """
        Read a JSON file and return its contents.
        If file doesn't exist, returns default value.
        
        Args:
            filename: Name of the JSON file (e.g., 'tickets.json')
            default: What to return if file doesn't exist
        
        Returns:
            The data from the file, or default if file missing/corrupted
        """
        filepath = self.base_dir / filename
        
        if not filepath.exists():
            if default is not None:
                self.write_json(filename, default)
            return default if default is not None else {}
        
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError) as e:
            print(f"⚠️ Error reading {filename}: {e}")
            return default if default is not None else {}
    
    def write_json(self, filename: str, data: Any) -> bool:
        """
        Write data to JSON file safely (atomic operation).
        Writes to temp file first, then renames to prevent corruption.
        
        Args:
            filename: Name of the JSON file
            data: Data to write (dict, list, etc.)
        
        Returns:
            True if successful, False otherwise
        """
        filepath = self.base_dir / filename
        
        try:
            # Create temp file in same directory
            temp_fd, temp_path = tempfile.mkstemp(
                dir=filepath.parent,
                prefix='.tmp_',
                suffix='.json'
            )
            
            # Write to temp file
            with os.fdopen(temp_fd, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=4, ensure_ascii=False)
            
            # Atomic rename (replaces old file safely)
            shutil.move(temp_path, filepath)
            return True
            
        except Exception as e:
            print(f"❌ Error writing {filename}: {e}")
            # Clean up temp file if it exists
            try:
                if 'temp_path' in locals():
                    os.remove(temp_path)
            except:
                pass
            return False
    
    def read_guild_data(self, guild_id: int, key: str, default: Any = None) -> Any:
        """
        Read guild-specific data from data/guilds/{guild_id}.json
        
        Args:
            guild_id: Discord server ID
            key: Data key to retrieve
            default: Default value if key doesn't exist
        """
        # Ensure guilds folder exists
        guilds_dir = self.base_dir / "guilds"
        guilds_dir.mkdir(exist_ok=True)
        
        guild_file = f"guilds/{guild_id}.json"
        guild_data = self.read_json(guild_file, default={})
        return guild_data.get(key, default)
    
    def write_guild_data(self, guild_id: int, key: str, value: Any) -> bool:
        """
        Write guild-specific data to data/guilds/{guild_id}.json
        
        Args:
            guild_id: Discord server ID
            key: Data key to set
            value: Value to store
        """
        # Ensure guilds folder exists
        guilds_dir = self.base_dir / "guilds"
        guilds_dir.mkdir(exist_ok=True)
        
        guild_file = f"guilds/{guild_id}.json"
        guild_data = self.read_json(guild_file, default={})
        guild_data[key] = value
        return self.write_json(guild_file, guild_data)

# Create a global instance that all cogs can use
data_manager = DataManager()
