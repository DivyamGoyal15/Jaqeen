# file: bot.py

"""
Discord Ticketing Bot - Production Version with Setup Wizard
"""

import discord
from discord.ext import commands
import asyncio
import os
import json
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

Path("data").mkdir(exist_ok=True)
Path("data/transcripts").mkdir(exist_ok=True)
Path("data/transcripts/txt").mkdir(exist_ok=True)
Path("data/transcripts/pdf").mkdir(exist_ok=True)
Path("data/attachments").mkdir(exist_ok=True)

def load_config():
    """Load or create the bot configuration file."""
    config_path = Path("config.json")
    default_config = {
        "default_prefix": "?"
    }
    
    if not config_path.exists():
        with open(config_path, 'w') as f:
            json.dump(default_config, f, indent=4)
        print("✅ Created config.json")
        return default_config
    
    try:
        with open(config_path, 'r') as f:
            return json.load(f)
    except json.JSONDecodeError:
        print("⚠️ config.json corrupted. Using defaults.")
        return default_config

CONFIG = load_config()

intents = discord.Intents.default()
intents.message_content = True
intents.members = True
intents.guilds = True

bot = commands.Bot(
    command_prefix="?",
    intents=intents,
    help_command=None,
    case_insensitive=True
)

@bot.event
async def on_ready():
    """Called when bot connects."""
    print("=" * 60)
    print(f"✅ Bot Online: {bot.user.name}")
    print(f"🆔 Bot ID: {bot.user.id}")
    print(f"📊 Servers: {len(bot.guilds)}")
    print("=" * 60)
    
    try:
        synced = await bot.tree.sync()
        print(f"✅ Synced {len(synced)} slash command(s)")
    except Exception as e:
        print(f"⚠️ Failed to sync: {e}")

@bot.event
async def on_guild_join(guild):
    """Called when bot joins a server."""
    print(f"➕ Joined: {guild.name}")

@bot.event
async def on_command_error(ctx, error):
    """Global error handler."""
    if isinstance(error, commands.CommandNotFound):
        return
    elif isinstance(error, commands.MissingPermissions):
        await ctx.send(f"❌ Missing permissions: {', '.join(error.missing_permissions)}")
    elif isinstance(error, commands.BotMissingPermissions):
        await ctx.send(f"❌ I need: {', '.join(error.missing_permissions)}")
    elif isinstance(error, commands.MissingRequiredArgument):
        await ctx.send(f"❌ Missing: `{error.param.name}`")
    else:
        await ctx.send(f"❌ Error: {str(error)}")
        print(f"Error: {error}")

async def load_cogs():
    """Load all cogs."""
    cogs_to_load = [
        "cogs.tickets",
        "cogs.help_commands"
    ]
    
    for cog in cogs_to_load:
        try:
            await bot.load_extension(cog)
            print(f"✅ Loaded {cog}")
        except Exception as e:
            print(f"❌ Failed to load {cog}: {e}")

async def main():
    """Main async function."""
    async with bot:
        await load_cogs()
        
        token = os.getenv("DISCORD_TOKEN")
        if not token:
            print("❌ ERROR: DISCORD_TOKEN not found!")
            print("Create a .env file with: DISCORD_TOKEN=your_token_here")
            return
        
        await bot.start(token)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n👋 Shutting down...")
