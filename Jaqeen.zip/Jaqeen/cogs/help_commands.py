# file: cogs/help_commands.py

"""
Help Commands - Beautiful and organized
"""

import discord
from discord.ext import commands
from discord import app_commands

class HelpCommands(commands.Cog):
    """Help system."""
    
    def __init__(self, bot):
        self.bot = bot
    
    @commands.command(name="help")
    async def help_cmd(self, ctx):
        """Show all commands."""
        await self.show_help(ctx)
    
    @app_commands.command(name="help", description="Show all commands")
    async def help_slash(self, interaction: discord.Interaction):
        """Help (slash)."""
        await interaction.response.defer()
        await self.show_help(interaction)
    
    async def show_help(self, ctx_or_interaction):
        """Display help."""
        is_interaction = isinstance(ctx_or_interaction, discord.Interaction)
        
        embed1 = discord.Embed(
            title="🎫 Ticket Bot - Commands",
            description="**Setup & Management**",
            color=discord.Color.blue()
        )
        
        setup_cmds = (
            "**?setup** or **/setup**\n"
            "Interactive setup wizard\n\n"
            "**?tickethistory [@user]** or **/ticket_history**\n"
            "View user's ticket history\n\n"
            "**?feedbackstats**\n"
            "View feedback statistics\n\n"
        )
        
        embed1.add_field(name="📋 Commands", value=setup_cmds, inline=False)
        
        embed2 = discord.Embed(
            title="🎫 Ticket Bot - In-Ticket Controls",
            description="**Buttons Inside Ticket Channel**",
            color=discord.Color.green()
        )
        
        controls = (
            "**✅ Claim** - Claim the ticket\n"
            "**📞 Call Staff** - Ping support role\n"
            "**📢 Call Creator** - Ping ticket creator\n"
            "**💾 Transcript** - Save TXT & PDF\n"
            "**🔒 Close** - Close & archive ticket\n\n"
            "**Slash Versions:**\n"
            "**/claim** - Claim ticket\n"
            "**/close** - Close ticket\n"
            "**/ticket_history @user** - User history\n"
        )
        
        embed2.add_field(name="🎮 Ticket Controls", value=controls, inline=False)
        
        embed3 = discord.Embed(
            title="🎫 Ticket Bot - Features",
            description="**What This Bot Can Do**",
            color=discord.Color.gold()
        )
        
        features = (
            "✅ Interactive setup wizard (like Ticket Tool)\n"
            "✅ Auto ticket numbering (ticket-1, ticket-2, etc.)\n"
            "✅ AI auto-responses (instant replies)\n"
            "✅ DM notifications (for important events)\n"
            "✅ TXT + PDF transcripts (auto-saved)\n"
            "✅ Feedback system (1-5 star ratings)\n"
            "✅ Ticket history search\n"
            "✅ Staff calling with pings\n"
            "✅ Private ticket channels\n"
            "✅ Category organization\n"
        )
        
        embed3.add_field(name="⭐ Features", value=features, inline=False)
        
        if is_interaction:
            await ctx_or_interaction.followup.send(embed=embed1)
            await ctx_or_interaction.followup.send(embed=embed2)
            await ctx_or_interaction.followup.send(embed=embed3)
        else:
            await ctx_or_interaction.send(embed=embed1)
            await ctx_or_interaction.send(embed=embed2)
            await ctx_or_interaction.send(embed=embed3)

async def setup(bot):
    await bot.add_cog(HelpCommands(bot))
