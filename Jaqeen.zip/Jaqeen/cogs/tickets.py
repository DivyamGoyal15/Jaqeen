# file: cogs/tickets.py

"""
Complete Ticketing System - SIMPLIFIED
Simple /sendpanel command with custom Jaqeen branding
"""

import discord
from discord.ext import commands, tasks
from discord import app_commands
from utils.data_manager import data_manager
import datetime
import re
from typing import Optional
import json
from pathlib import Path
import asyncio
from collections import defaultdict

try:
    from reportlab.lib.pagesizes import letter
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    PDF_AVAILABLE = True
except ImportError:
    PDF_AVAILABLE = False

ticket_counters = defaultdict(int)

class TicketControlButtons(discord.ui.View):
    """Control buttons inside ticket channel."""
    
    def __init__(self, bot):
        super().__init__(timeout=None)
        self.bot = bot
    
    @discord.ui.button(label="✅ Claim", style=discord.ButtonStyle.green, custom_id="ticket_claim_btn")
    async def claim_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        cog = interaction.client.get_cog("Tickets")
        if cog:
            await cog.claim_ticket(interaction, from_button=True)
    
    @discord.ui.button(label="📞 Call Staff", style=discord.ButtonStyle.blurple, custom_id="ticket_call_staff")
    async def call_staff_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        cog = interaction.client.get_cog("Tickets")
        if cog:
            await cog.call_staff(interaction)
    
    @discord.ui.button(label="📢 Call Creator", style=discord.ButtonStyle.primary, custom_id="ticket_call_creator")
    async def call_creator_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        cog = interaction.client.get_cog("Tickets")
        if cog:
            await cog.call_ticket_creator(interaction)
    
    @discord.ui.button(label="💾 Transcript", style=discord.ButtonStyle.blurple, custom_id="ticket_transcript")
    async def transcript_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        cog = interaction.client.get_cog("Tickets")
        if cog:
            await cog.save_transcript_button(interaction)
    
    @discord.ui.button(label="🔒 Close", style=discord.ButtonStyle.red, custom_id="ticket_close")
    async def close_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        cog = interaction.client.get_cog("Tickets")
        if cog:
            await cog.close_ticket(interaction, from_button=True)

class JaqeenPanelButtons(discord.ui.View):
    """Jaqeen custom panel buttons."""
    
    def __init__(self, bot):
        super().__init__(timeout=None)
        self.bot = bot
    
    @discord.ui.button(label="⚠️ Report / Issue", style=discord.ButtonStyle.red, custom_id="ticket_report")
    async def report_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        cog = interaction.client.get_cog("Tickets")
        if cog:
            await cog.handle_ticket_creation(interaction, "Report / Issue")
    
    @discord.ui.button(label="🧑‍💼 Staff Application", style=discord.ButtonStyle.green, custom_id="ticket_staff_app")
    async def staff_app_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        cog = interaction.client.get_cog("Tickets")
        if cog:
            await cog.handle_ticket_creation(interaction, "Staff Application")
    
    @discord.ui.button(label="🎁 Giveaway Prize Claim", style=discord.ButtonStyle.blurple, custom_id="ticket_giveaway")
    async def giveaway_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        cog = interaction.client.get_cog("Tickets")
        if cog:
            await cog.handle_ticket_creation(interaction, "Giveaway Prize Claim")

class CloseReasonModal(discord.ui.Modal, title="Close Reason"):
    """Ask for close reason."""
    
    reason = discord.ui.TextInput(
        label="Why are you closing?",
        style=discord.TextStyle.paragraph,
        required=True,
        max_length=500
    )
    
    async def on_submit(self, interaction: discord.Interaction):
        cog = interaction.client.get_cog("Tickets")
        if cog:
            guild_key = str(interaction.guild.id)
            tickets_data = data_manager.read_json("tickets.json", default={})
            
            ticket_id = None
            if guild_key in tickets_data:
                for tid, tinfo in tickets_data[guild_key].items():
                    if tinfo.get("channel_id") == interaction.channel.id:
                        ticket_id = tid
                        break
            
            if ticket_id:
                await cog.finalize_close_ticket(
                    interaction,
                    self.reason.value,
                    ticket_id
                )

class FeedbackView(discord.ui.View):
    """Feedback stars."""
    
    def __init__(self, cog, ticket_id: int, guild_id: int):
        super().__init__(timeout=300)
        self.cog = cog
        self.ticket_id = ticket_id
        self.guild_id = guild_id
        self.already_rated = False
    
    @discord.ui.button(label="⭐", style=discord.ButtonStyle.grey)
    async def rating_1(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.already_rated:
            await self.handle_rating(interaction, 1)
    
    @discord.ui.button(label="⭐⭐", style=discord.ButtonStyle.grey)
    async def rating_2(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.already_rated:
            await self.handle_rating(interaction, 2)
    
    @discord.ui.button(label="⭐⭐⭐", style=discord.ButtonStyle.grey)
    async def rating_3(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.already_rated:
            await self.handle_rating(interaction, 3)
    
    @discord.ui.button(label="⭐⭐⭐⭐", style=discord.ButtonStyle.blurple)
    async def rating_4(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.already_rated:
            await self.handle_rating(interaction, 4)
    
    @discord.ui.button(label="⭐⭐⭐⭐⭐", style=discord.ButtonStyle.green)
    async def rating_5(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.already_rated:
            await self.handle_rating(interaction, 5)
    
    async def handle_rating(self, interaction: discord.Interaction, rating: int):
        """Save rating once."""
        self.already_rated = True
        await interaction.response.defer(ephemeral=True)
        
        feedback_data = data_manager.read_json("feedback.json", default={})
        guild_key = str(self.guild_id)
        
        if guild_key not in feedback_data:
            feedback_data[guild_key] = []
        
        feedback_entry = {
            "ticket_id": self.ticket_id,
            "user_id": interaction.user.id,
            "rating": rating,
            "timestamp": datetime.datetime.utcnow().isoformat()
        }
        
        feedback_data[guild_key].append(feedback_entry)
        data_manager.write_json("feedback.json", feedback_data)
        
        await interaction.followup.send(f"✅ Rating: {'⭐' * rating}", ephemeral=True)
        self.stop()

class Tickets(commands.Cog):
    """Complete ticketing system."""
    
    def __init__(self, bot):
        self.bot = bot
        self.ticket_health_monitor.start()
    
    def cog_unload(self):
        self.ticket_health_monitor.cancel()
    
    # ==================== SEND PANEL COMMAND ====================
    
    @commands.command(name="sendpanel")
    @commands.has_permissions(administrator=True)
    async def sendpanel_cmd(self, ctx):
        """Send Jaqeen support panel to current channel."""
        await self.send_jaqeen_panel(ctx)
    
    @app_commands.command(name="sendpanel", description="Send Jaqeen support panel")
    @app_commands.checks.has_permissions(administrator=True)
    async def sendpanel_slash(self, interaction: discord.Interaction):
        """Send panel (slash)."""
        await interaction.response.defer()
        await self.send_jaqeen_panel(interaction)
    
    async def send_jaqeen_panel(self, ctx_or_interaction):
        """Send beautiful Jaqeen panel."""
        if isinstance(ctx_or_interaction, discord.Interaction):
            channel = ctx_or_interaction.channel
            is_interaction = True
            interaction = ctx_or_interaction
        else:
            ctx = ctx_or_interaction
            channel = ctx.channel
            is_interaction = False
        
        # Create beautiful Jaqeen embed
        embed = discord.Embed(
            title="🎟️・Jaqeen Support Center",
            description=(
                "Got an issue, idea, or want to talk in private?\n\n"
                "Tap the button below to open a ticket 💬  \n"
                "We'll slide in soon — stay chill 💫"
            ),
            color=discord.Color.from_str("#B39DDB")  # Purple hex
        )
        
        embed.set_footer(text="💖 Thank you for being part of Jaqeen — your comfort zone on Discord.")
        
        view = JaqeenPanelButtons(self.bot)
        
        try:
            await channel.send(embed=embed, view=view)
            
            if is_interaction:
                await interaction.followup.send("✅ Jaqeen panel sent!", ephemeral=True)
            else:
                await ctx.send("✅ Jaqeen panel sent!")
        except Exception as e:
            if is_interaction:
                await interaction.followup.send(f"❌ Error: {e}", ephemeral=True)
            else:
                await ctx.send(f"❌ Error: {e}")
    
    # ==================== SETUP SUPPORT ROLE ====================
    
    @commands.command(name="setsupportrole")
    @commands.has_permissions(administrator=True)
    async def set_support_role(self, ctx, role: discord.Role):
        """Set the support team role."""
        data_manager.write_guild_data(ctx.guild.id, "support_role", role.id)
        await ctx.send(f"✅ Support role set to {role.mention}")
    
    @app_commands.command(name="setsupportrole", description="Set support role")
    @app_commands.describe(role="Support role")
    @app_commands.checks.has_permissions(administrator=True)
    async def setsupportrole_slash(self, interaction: discord.Interaction, role: discord.Role):
        """Set support role (slash)."""
        data_manager.write_guild_data(interaction.guild.id, "support_role", role.id)
        await interaction.response.send_message(f"✅ Support role set to {role.mention}")
    
    # ==================== SETUP TRANSCRIPT CHANNEL ====================
    
    @commands.command(name="settranscriptchannel")
    @commands.has_permissions(administrator=True)
    async def set_transcript_channel(self, ctx, channel: discord.TextChannel):
        """Set the transcript channel."""
        data_manager.write_guild_data(ctx.guild.id, "transcript_channel", channel.id)
        await ctx.send(f"✅ Transcript channel set to {channel.mention}")
    
    @app_commands.command(name="settranscriptchannel", description="Set transcript channel")
    @app_commands.describe(channel="Transcript channel")
    @app_commands.checks.has_permissions(administrator=True)
    async def settranscriptchannel_slash(self, interaction: discord.Interaction, channel: discord.TextChannel):
        """Set transcript channel (slash)."""
        data_manager.write_guild_data(interaction.guild.id, "transcript_channel", channel.id)
        await interaction.response.send_message(f"✅ Transcript channel set to {channel.mention}")
    
    # ==================== SETUP LOG CHANNEL ====================
    
    @commands.command(name="setlogchannel")
    @commands.has_permissions(administrator=True)
    async def set_log_channel(self, ctx, channel: discord.TextChannel):
        """Set the log channel for ticket events."""
        data_manager.write_guild_data(ctx.guild.id, "logger_channel", channel.id)
        await ctx.send(f"✅ Log channel set to {channel.mention}")
    
    @app_commands.command(name="setlogchannel", description="Set log channel")
    @app_commands.describe(channel="Log channel")
    @app_commands.checks.has_permissions(administrator=True)
    async def setlogchannel_slash(self, interaction: discord.Interaction, channel: discord.TextChannel):
        """Set log channel (slash)."""
        data_manager.write_guild_data(interaction.guild.id, "logger_channel", channel.id)
        await interaction.response.send_message(f"✅ Log channel set to {channel.mention}")
    
    # ==================== TICKET CREATION ====================
    
    async def handle_ticket_creation(self, interaction: discord.Interaction, ticket_type: str):
        """Create a new ticket."""
        guild = interaction.guild
        guild_key = str(guild.id)
        
        # Check existing ticket
        tickets_data = data_manager.read_json("tickets.json", default={})
        
        if guild_key in tickets_data:
            for ticket_id, ticket_info in tickets_data[guild_key].items():
                if (ticket_info.get("user_id") == interaction.user.id and 
                    ticket_info.get("status") == "open"):
                    channel = guild.get_channel(ticket_info.get("channel_id"))
                    if channel:
                        await interaction.followup.send(
                            f"❌ You have open ticket: {channel.mention}",
                            ephemeral=True
                        )
                        return
        
        # Generate ticket number
        ticket_counters[guild_key] += 1
        ticket_number = ticket_counters[guild_key]
        
        # Create channel
        channel_name = f"ticket-{ticket_number}"
        
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(read_messages=False),
            interaction.user: discord.PermissionOverwrite(
                read_messages=True,
                send_messages=True,
                attach_files=True
            ),
            guild.me: discord.PermissionOverwrite(
                read_messages=True,
                send_messages=True,
                manage_channels=True
            )
        }
        
        try:
            ticket_channel = await guild.create_text_channel(
                name=channel_name,
                overwrites=overwrites
            )
        except discord.Forbidden:
            await interaction.followup.send("❌ Can't create channels!", ephemeral=True)
            return
        
        # Save ticket
        ticket_id = f"{guild_key}_{ticket_number}"
        
        if guild_key not in tickets_data:
            tickets_data[guild_key] = {}
        
        tickets_data[guild_key][ticket_id] = {
            "number": ticket_number,
            "user_id": interaction.user.id,
            "channel_id": ticket_channel.id,
            "type": ticket_type,
            "status": "open",
            "created_at": datetime.datetime.utcnow().isoformat(),
            "claimed_by": None,
            "closed_at": None,
            "closed_by": None,
            "close_reason": None,
            "rated": False
        }
        
        data_manager.write_json("tickets.json", tickets_data)
        
        # Welcome message
        welcome_embed = discord.Embed(
            title=f"🎫 Ticket #{ticket_number}",
            description=(
                f"**Type:** {ticket_type}\n"
                f"**Created by:** {interaction.user.mention}\n\n"
                f"Please describe your issue!"
            ),
            color=discord.Color.from_str("#B39DDB"),
            timestamp=datetime.datetime.utcnow()
        )
        
        view = TicketControlButtons(self.bot)
        await ticket_channel.send(embed=welcome_embed, view=view)
        
        await interaction.followup.send(f"✅ Ticket: {ticket_channel.mention}", ephemeral=True)
        
        # Log ticket creation
        logger_channel_id = data_manager.read_guild_data(guild.id, "logger_channel")
        if logger_channel_id:
            logger_channel = guild.get_channel(logger_channel_id)
            if logger_channel:
                log_embed = discord.Embed(
                    title="🎫 New Ticket",
                    color=discord.Color.green()
                )
                log_embed.add_field(name="ID", value=f"#{ticket_number}", inline=True)
                log_embed.add_field(name="User", value=interaction.user.mention, inline=True)
                log_embed.add_field(name="Type", value=ticket_type, inline=True)
                log_embed.add_field(name="Channel", value=ticket_channel.mention, inline=False)
                log_embed.timestamp = datetime.datetime.utcnow()
                try:
                    await logger_channel.send(embed=log_embed)
                except:
                    pass
    
    # ==================== CLAIM TICKET ====================
    
    @commands.command(name="claim")
    async def claim_cmd(self, ctx):
        """Claim a ticket."""
        await self.claim_ticket(ctx, from_button=False)
    
    @app_commands.command(name="claim", description="Claim this ticket")
    async def claim_slash(self, interaction: discord.Interaction):
        """Claim (slash)."""
        await self.claim_ticket(interaction, from_button=False)
    
    async def claim_ticket(self, ctx_or_interaction, from_button: bool = False):
        """Handle claiming."""
        if isinstance(ctx_or_interaction, discord.Interaction):
            interaction = ctx_or_interaction
            channel = interaction.channel
            user = interaction.user
            guild = interaction.guild
            is_interaction = True
        else:
            ctx = ctx_or_interaction
            channel = ctx.channel
            user = ctx.author
            guild = ctx.guild
            is_interaction = False
        
        guild_key = str(guild.id)
        tickets_data = data_manager.read_json("tickets.json", default={})
        
        ticket_id = None
        ticket_info = None
        
        if guild_key in tickets_data:
            for tid, tinfo in tickets_data[guild_key].items():
                if tinfo.get("channel_id") == channel.id:
                    ticket_id = tid
                    ticket_info = tinfo
                    break
        
        if not ticket_info:
            msg = "❌ Not a ticket!"
            if from_button:
                await interaction.response.send_message(msg, ephemeral=True)
            elif is_interaction:
                await interaction.response.send_message(msg, ephemeral=True)
            else:
                await ctx.send(msg)
            return
        
        if ticket_info.get("claimed_by"):
            claimer = guild.get_member(ticket_info["claimed_by"])
            msg = f"❌ Already claimed by {claimer.mention if claimer else 'someone'}"
            if from_button:
                await interaction.response.send_message(msg, ephemeral=True)
            elif is_interaction:
                await interaction.response.send_message(msg, ephemeral=True)
            else:
                await ctx.send(msg)
            return
        
        # Claim
        tickets_data[guild_key][ticket_id]["claimed_by"] = user.id
        data_manager.write_json("tickets.json", tickets_data)
        
        embed = discord.Embed(
            title="✅ Claimed",
            description=f"{user.mention} claimed this!",
            color=discord.Color.from_str("#B39DDB")
        )
        
        if from_button:
            await interaction.response.send_message(embed=embed)
        elif is_interaction:
            await interaction.response.send_message(embed=embed)
        else:
            await ctx.send(embed=embed)
    
    async def call_staff(self, interaction: discord.Interaction):
        """Call support staff."""
        await interaction.response.defer(ephemeral=True)
        
        guild = interaction.guild
        
        # Find support role
        support_role_id = data_manager.read_guild_data(guild.id, "support_role")
        support_role = guild.get_role(support_role_id) if support_role_id else None
        
        if not support_role:
            await interaction.followup.send("❌ No support role set!", ephemeral=True)
            return
        
        embed = discord.Embed(
            title="📞 Staff Called",
            description=f"{interaction.user.mention} needs help!",
            color=discord.Color.orange()
        )
        
        # Send message with mention
        await interaction.channel.send(f"{support_role.mention}", embed=embed)
        await interaction.followup.send("✅ Staff called!", ephemeral=True)
    
    async def call_ticket_creator(self, interaction: discord.Interaction):
        """Call ticket creator."""
        await interaction.response.defer(ephemeral=True)
        
        guild = interaction.guild
        guild_key = str(guild.id)
        
        tickets_data = data_manager.read_json("tickets.json", default={})
        
        ticket_info = None
        
        if guild_key in tickets_data:
            for tid, tinfo in tickets_data[guild_key].items():
                if tinfo.get("channel_id") == interaction.channel.id:
                    ticket_info = tinfo
                    break
        
        if not ticket_info:
            await interaction.followup.send("❌ Not a ticket!", ephemeral=True)
            return
        
        creator = guild.get_member(ticket_info["user_id"])
        
        if not creator:
            await interaction.followup.send("❌ Creator not found!", ephemeral=True)
            return
        
        embed = discord.Embed(
            title="📢 You're Called",
            description="Staff needs your response!",
            color=discord.Color.purple()
        )
        
        await interaction.channel.send(f"{creator.mention}", embed=embed)
        await interaction.followup.send("✅ Creator called!", ephemeral=True)
    
    async def save_transcript_button(self, interaction: discord.Interaction):
        """Save transcript."""
        await interaction.response.defer(ephemeral=True)
        
        guild = interaction.guild
        guild_key = str(guild.id)
        
        tickets_data = data_manager.read_json("tickets.json", default={})
        
        ticket_id = None
        
        if guild_key in tickets_data:
            for tid, tinfo in tickets_data[guild_key].items():
                if tinfo.get("channel_id") == interaction.channel.id:
                    ticket_id = tid
                    break
        
        if not ticket_id:
            await interaction.followup.send("❌ Not found!", ephemeral=True)
            return
        
        txt_path = await self.save_transcript_txt(interaction.channel, ticket_id)
        pdf_path = await self.save_transcript_pdf(interaction.channel, ticket_id) if PDF_AVAILABLE else None
        
        files = []
        if txt_path and Path(txt_path).exists():
            files.append(discord.File(txt_path))
        if pdf_path and Path(pdf_path).exists():
            files.append(discord.File(pdf_path))
        
        if files:
            await interaction.followup.send("✅ Saved!", files=files, ephemeral=True)
        else:
            await interaction.followup.send("❌ Failed!", ephemeral=True)
    
    async def save_transcript_txt(self, channel: discord.TextChannel, ticket_id: str) -> Optional[str]:
        """Save TXT."""
        try:
            messages = []
            async for message in channel.history(limit=None, oldest_first=True):
                timestamp = message.created_at.strftime("%Y-%m-%d %H:%M:%S")
                author = str(message.author)
                content = message.content or "[No text]"
                
                msg_str = f"[{timestamp}] {author}: {content}"
                if message.attachments:
                    msg_str += "\n  Files: " + ", ".join(a.url for a in message.attachments)
                
                messages.append(msg_str)
            
            transcript_dir = Path(f"data/transcripts/txt/{channel.guild.id}")
            transcript_dir.mkdir(parents=True, exist_ok=True)
            
            transcript_path = transcript_dir / f"ticket_{ticket_id}.txt"
            
            with open(transcript_path, 'w', encoding='utf-8') as f:
                f.write(f"TICKET #{ticket_id}\n")
                f.write(f"Channel: {channel.name}\n")
                f.write(f"Server: {channel.guild.name}\n")
                f.write(f"Saved: {datetime.datetime.utcnow().isoformat()}\n")
                f.write("=" * 70 + "\n\n")
                f.write("\n".join(messages))
            
            return str(transcript_path)
        except Exception as e:
            print(f"Error: {e}")
            return None
    
    async def save_transcript_pdf(self, channel: discord.TextChannel, ticket_id: str) -> Optional[str]:
        """Save PDF."""
        if not PDF_AVAILABLE:
            return None
        
        try:
            messages = []
            async for message in channel.history(limit=None, oldest_first=True):
                messages.append((
                    message.created_at.strftime("%Y-%m-%d %H:%M:%S"),
                    str(message.author),
                    message.content or "[No text]"
                ))
            
            transcript_dir = Path(f"data/transcripts/pdf/{channel.guild.id}")
            transcript_dir.mkdir(parents=True, exist_ok=True)
            
            pdf_path = transcript_dir / f"ticket_{ticket_id}.pdf"
            
            doc = SimpleDocTemplate(str(pdf_path), pagesize=letter)
            styles = getSampleStyleSheet()
            story = []
            
            title_style = ParagraphStyle(
                'Title',
                parent=styles['Heading1'],
                fontSize=16,
                textColor=colors.HexColor('#B39DDB')
            )
            
            story.append(Paragraph(f"Ticket #{ticket_id}", title_style))
            story.append(Spacer(1, 0.2 * 72))
            story.append(Paragraph(f"<b>Channel:</b> {channel.name}", styles['Normal']))
            story.append(Spacer(1, 0.3 * 72))
            
            table_data = [["Time", "Author", "Message"]]
            for timestamp, author, content in messages[-100:]:
                table_data.append([timestamp[:16], author[:20], content[:80]])
            
            table = Table(table_data, colWidths=[80, 100, 216])
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#B39DDB')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            
            story.append(table)
            doc.build(story)
            
            return str(pdf_path)
        except Exception as e:
            print(f"Error: {e}")
            return None
    
    @commands.command(name="close")
    async def close_cmd(self, ctx):
        """Close ticket."""
        await self.close_ticket(ctx, from_button=False)
    
    @app_commands.command(name="close", description="Close ticket")
    async def close_slash(self, interaction: discord.Interaction):
        """Close (slash)."""
        await self.close_ticket(interaction, from_button=False)
    
    async def close_ticket(self, ctx_or_interaction, from_button: bool = False):
        """Handle closing."""
        if isinstance(ctx_or_interaction, discord.Interaction):
            interaction = ctx_or_interaction
            channel = interaction.channel
            guild = interaction.guild
            is_interaction = True
        else:
            ctx = ctx_or_interaction
            channel = ctx.channel
            guild = ctx.guild
            is_interaction = False
        
        guild_key = str(guild.id)
        tickets_data = data_manager.read_json("tickets.json", default={})
        
        ticket_id = None
        
        if guild_key in tickets_data:
            for tid, tinfo in tickets_data[guild_key].items():
                if tinfo.get("channel_id") == channel.id:
                    ticket_id = tid
                    break
        
        if not ticket_id:
            msg = "❌ Not a ticket!"
            if from_button:
                await interaction.response.send_message(msg, ephemeral=True)
            elif is_interaction:
                await interaction.response.send_message(msg, ephemeral=True)
            else:
                await ctx.send(msg)
            return
        
        # Show modal for reason
        if is_interaction:
            modal = CloseReasonModal()
            await interaction.response.send_modal(modal)
        else:
            await self.finalize_close_ticket(ctx, "No reason", ticket_id)
    
    async def finalize_close_ticket(self, ctx_or_interaction, close_reason: str, ticket_id: str):
        """Actually close the ticket."""
        if isinstance(ctx_or_interaction, discord.Interaction):
            interaction = ctx_or_interaction
            channel = interaction.channel
            user = interaction.user
            guild = interaction.guild
            is_interaction = True
        else:
            ctx = ctx_or_interaction
            channel = ctx.channel
            user = ctx.author
            guild = ctx.guild
            is_interaction = False
        
        guild_key = str(guild.id)
        tickets_data = data_manager.read_json("tickets.json", default={})
        
        if guild_key not in tickets_data or ticket_id not in tickets_data[guild_key]:
            return
        
        ticket_info = tickets_data[guild_key][ticket_id]
        
        # Mark as closed
        tickets_data[guild_key][ticket_id]["status"] = "closed"
        tickets_data[guild_key][ticket_id]["closed_at"] = datetime.datetime.utcnow().isoformat()
        tickets_data[guild_key][ticket_id]["closed_by"] = user.id
        tickets_data[guild_key][ticket_id]["close_reason"] = close_reason
        tickets_data[guild_key][ticket_id]["rated"] = False
        data_manager.write_json("tickets.json", tickets_data)
        
        # Save transcripts
        txt_path = await self.save_transcript_txt(channel, ticket_id)
        pdf_path = await self.save_transcript_pdf(channel, ticket_id) if PDF_AVAILABLE else None
        
        # Send feedback (ONLY ONCE)
        ticket_creator = guild.get_member(ticket_info["user_id"])
        if ticket_creator and not ticket_info.get("rated", False):
            try:
                ticket_num = ticket_info.get("number", "N/A")
                feedback_view = FeedbackView(self, int(ticket_num), guild.id)
                feedback_embed = discord.Embed(
                    title="⭐ Rate Your Experience",
                    description=f"Ticket #{ticket_num} closed!",
                    color=discord.Color.from_str("#B39DDB")
                )
                await ticket_creator.send(embed=feedback_embed, view=feedback_view)
                
                # Mark as rated
                tickets_data[guild_key][ticket_id]["rated"] = True
                data_manager.write_json("tickets.json", tickets_data)
            except:
                pass
        
        # Send to transcript channel
        transcript_channel_id = data_manager.read_guild_data(guild.id, "transcript_channel")
        
        if transcript_channel_id:
            transcript_channel = guild.get_channel(transcript_channel_id)
            if transcript_channel:
                transcript_embed = discord.Embed(
                    title="📄 Ticket Closed",
                    color=discord.Color.from_str("#B39DDB")
                )
                transcript_embed.add_field(name="ID", value=f"#{ticket_info.get('number', 'N/A')}", inline=True)
                transcript_embed.add_field(name="Reason", value=close_reason, inline=False)
                
                files = []
                if txt_path and Path(txt_path).exists():
                    files.append(discord.File(txt_path))
                if pdf_path and Path(pdf_path).exists():
                    files.append(discord.File(pdf_path))
                
                try:
                    await transcript_channel.send(embed=transcript_embed, files=files if files else None)
                except:
                    pass
        
        # Log ticket closing
        logger_channel_id = data_manager.read_guild_data(guild.id, "logger_channel")
        if logger_channel_id:
            logger_channel = guild.get_channel(logger_channel_id)
            if logger_channel:
                log_embed = discord.Embed(
                    title="🔒 Ticket Closed",
                    color=discord.Color.red()
                )
                log_embed.add_field(name="ID", value=f"#{ticket_info.get('number', 'N/A')}", inline=True)
                log_embed.add_field(name="Closed by", value=user.mention, inline=True)
                log_embed.add_field(name="Reason", value=close_reason, inline=False)
                log_embed.timestamp = datetime.datetime.utcnow()
                try:
                    await logger_channel.send(embed=log_embed)
                except:
                    pass
        
        # Delete channel
        try:
            await channel.send("Deleting in 5 seconds...")
            await discord.utils.sleep_until(discord.utils.utcnow() + datetime.timedelta(seconds=5))
            await channel.delete(reason=f"Ticket closed")
        except:
            pass
    
    @commands.command(name="tickethistory")
    @commands.has_permissions(administrator=True)
    async def ticket_history_cmd(self, ctx, user: Optional[discord.User] = None):
        """View ticket history."""
        await self.ticket_history(ctx, user)
    
    @app_commands.command(name="ticket_history", description="View ticket history")
    @app_commands.describe(user="User to check")
    async def ticket_history_slash(self, interaction: discord.Interaction, user: Optional[discord.User] = None):
        """Ticket history (slash)."""
        await interaction.response.defer()
        await self.ticket_history(interaction, user)
    
    async def ticket_history(self, ctx_or_interaction, user: Optional[discord.User] = None):
        """Get ticket history."""
        if isinstance(ctx_or_interaction, discord.Interaction):
            interaction = ctx_or_interaction
            guild = interaction.guild
            author = interaction.user
            is_interaction = True
        else:
            ctx = ctx_or_interaction
            guild = ctx.guild
            author = ctx.author
            is_interaction = False
        
        if not user:
            user = author
        
        guild_key = str(guild.id)
        tickets_data = data_manager.read_json("tickets.json", default={})
        
        user_tickets = []
        if guild_key in tickets_data:
            for tid, tinfo in tickets_data[guild_key].items():
                if tinfo.get("user_id") == user.id:
                    user_tickets.append((tid, tinfo))
        
        if not user_tickets:
            msg = f"No tickets for {user.mention}"
            if is_interaction:
                await interaction.followup.send(msg)
            else:
                await ctx.send(msg)
            return
        
        embed = discord.Embed(
            title=f"Ticket History - {user}",
            color=discord.Color.from_str("#B39DDB"),
            description=f"Total: {len(user_tickets)}"
        )
        
        for tid, tinfo in sorted(user_tickets, key=lambda x: x[1]['created_at'], reverse=True)[:10]:
            ticket_num = tinfo.get('number', 'N/A')
            status = tinfo.get('status', 'Unknown')
            ticket_type = tinfo.get('type', 'Unknown')
            reason = tinfo.get('close_reason', 'N/A')[:50]
            
            value = f"**#** {ticket_num}\n**Status:** {status}\n**Type:** {ticket_type}\n**Reason:** {reason}"
            embed.add_field(name=f"ID: {tid}", value=value, inline=False)
        
        if is_interaction:
            await interaction.followup.send(embed=embed)
        else:
            await ctx.send(embed=embed)
    
    @commands.command(name="feedbackstats")
    @commands.has_permissions(administrator=True)
    async def feedback_stats(self, ctx):
        """View feedback stats."""
        feedback_data = data_manager.read_json("feedback.json", default={})
        guild_key = str(ctx.guild.id)
        
        if guild_key not in feedback_data or not feedback_data[guild_key]:
            await ctx.send("❌ No feedback yet!")
            return
        
        guild_feedback = feedback_data[guild_key]
        total = len(guild_feedback)
        ratings = [f["rating"] for f in guild_feedback]
        average = sum(ratings) / len(ratings) if ratings else 0
        
        rating_counts = {i: ratings.count(i) for i in range(1, 6)}
        
        embed = discord.Embed(
            title="📊 Feedback Stats",
            color=discord.Color.from_str("#B39DDB")
        )
        
        embed.add_field(name="Total", value=str(total), inline=True)
        embed.add_field(name="Average", value=f"{average:.2f} ⭐", inline=True)
        embed.add_field(name="\u200b", value="\u200b", inline=True)
        
        for rating in range(5, 0, -1):
            count = rating_counts.get(rating, 0)
            percentage = (count / total * 100) if total > 0 else 0
            embed.add_field(
                name=f"{'⭐' * rating}",
                value=f"{count} ({percentage:.1f}%)",
                inline=False
            )
        
        await ctx.send(embed=embed)
    
    @tasks.loop(hours=1)
    async def ticket_health_monitor(self):
        """Monitor health."""
        await self.bot.wait_until_ready()

async def setup(bot):
    """Load cog."""
    cog = Tickets(bot)
    await bot.add_cog(cog)
